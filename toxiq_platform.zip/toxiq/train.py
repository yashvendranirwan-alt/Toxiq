"""
=============================================================================
ToxIQ | train.py
Main Training Entry Point
=============================================================================

USAGE:
    python train.py --data path/to/tox21.csv --model-dir models/

    # To skip cross-validation for faster runs:
    python train.py --data tox21.csv --no-cv

DATA ACQUISITION:
    Download the Tox21 dataset from Kaggle:
    https://www.kaggle.com/datasets/epicskills/tox21-dataset

    Place the downloaded CSV in the project root as 'tox21.csv'

Author: ToxIQ Engineering Team
=============================================================================
"""

import argparse
import json
import logging
import os
import sys

import numpy as np
import joblib

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.data_pipeline import run_data_pipeline
from src.model_trainer import train_all_tasks

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("ToxIQ.Train")


def main():
    parser = argparse.ArgumentParser(
        description="ToxIQ — Drug Toxicity Prediction Training Pipeline",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--data",
        type=str,
        default="tox21.csv",
        help="Path to Tox21 CSV dataset",
    )
    parser.add_argument(
        "--model-dir",
        type=str,
        default="models/",
        help="Directory to save trained models",
    )
    parser.add_argument(
        "--no-cv",
        action="store_true",
        help="Skip cross-validation (faster, no performance metrics)",
    )
    args = parser.parse_args()

    if not os.path.exists(args.data):
        logger.error(f"Dataset not found: {args.data}")
        logger.error("Download from: https://www.kaggle.com/datasets/epicskills/tox21-dataset")
        sys.exit(1)

    # === PHASE 1: Data Engineering ===
    logger.info("PHASE 1: Data Engineering & Cheminformatics Featurization")
    pipeline_output = run_data_pipeline(args.data)

    X = pipeline_output["X"]
    Y = pipeline_output["Y"]
    feature_names = pipeline_output["feature_names"]
    assay_names = pipeline_output["assay_names"]
    valid_df = pipeline_output["valid_df"]

    # Save feature names and assay list for inference
    os.makedirs(args.model_dir, exist_ok=True)
    joblib.dump(feature_names, os.path.join(args.model_dir, "feature_names.pkl"))
    with open(os.path.join(args.model_dir, "assay_names.json"), "w") as f:
        json.dump(assay_names, f)

    logger.info(f"Feature matrix: {X.shape}")
    logger.info(f"Label matrix: {Y.shape} ({len(assay_names)} assays)")

    # === PHASE 2: Model Training ===
    logger.info("\nPHASE 2: Multi-Task XGBoost Model Training")
    models, scalers, metrics = train_all_tasks(
        X=X,
        Y=Y,
        assay_names=assay_names,
        model_dir=args.model_dir,
        use_cv=not args.no_cv,
    )

    logger.info(f"\n{'='*60}")
    logger.info("TRAINING COMPLETE")
    logger.info(f"{'='*60}")
    logger.info(f"Models saved to: {args.model_dir}/")
    logger.info(f"  - {len(models)} task-specific XGBoost models (.pkl)")
    logger.info(f"  - {len(scalers)} task-specific StandardScalers (.pkl)")
    logger.info(f"  - feature_names.pkl")
    logger.info(f"  - assay_names.json")
    logger.info(f"  - training_metrics.json")
    logger.info(f"\nNext step: streamlit run app.py")


if __name__ == "__main__":
    main()
