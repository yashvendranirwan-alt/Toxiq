"""
=============================================================================
ToxIQ | src/model_trainer.py
Multi-Task XGBoost Toxicity Prediction Model
=============================================================================

PURPOSE:
    Train, evaluate, and serialize an ensemble of XGBoost classifiers — one
    per Tox21 assay — using a shared feature space (Morgan FP + descriptors).
    Implements cross-validation, threshold optimization, and comprehensive
    evaluation metrics appropriate for imbalanced medical ML tasks.

ARCHITECTURAL PHILOSOPHY — MULTI-TASK LEARNING:
    Why train 12 separate models on the same features rather than one
    independent model per assay?

    1. SHARED REPRESENTATION:
       All 12 assays use identical feature vectors (Morgan FP + descriptors).
       The features learned to predict NR-AR toxicity often generalize to
       NR-ER toxicity — both involve nuclear receptor binding. Shared
       representation benefits all tasks.

    2. DATA EFFICIENCY:
       Some assays have very few labeled compounds. By training all assays
       together (or at minimum using the same hyperparameters tuned across
       all tasks), we transfer signal from data-rich assays to data-poor ones.

    3. PRACTICAL MULTI-TASK APPROACH:
       True multi-task learning (joint loss) is complex with XGBoost.
       Our approach: train one XGBoost per task, but with shared
       hyperparameters tuned via multi-task cross-validation — capturing
       the spirit of multi-task learning with XGBoost's power.

    4. CLINICAL INTERPRETABILITY:
       Per-assay models allow targeted SHAP analysis: "what drives
       estrogen receptor binding specifically?" — more actionable than
       a single joint model.

EVALUATION PHILOSOPHY:
    We use ROC-AUC as primary metric, NOT accuracy.

    WHY NOT ACCURACY?
        If 5% of compounds are toxic (class 1), a model predicting
        "non-toxic" always achieves 95% accuracy. Useless.

    WHY ROC-AUC?
        AUC measures ranking quality — does the model assign higher
        probability to toxic vs. non-toxic compounds? AUC = 0.5 is random,
        AUC = 1.0 is perfect. It's threshold-independent and handles
        class imbalance correctly.

    WE ALSO REPORT:
        - PR-AUC (Precision-Recall): better for extreme imbalance
        - MCC (Matthews Correlation Coefficient): balanced metric
        - Sensitivity / Specificity: clinical relevance

Author: ToxIQ Engineering Team
=============================================================================
"""

import os
import logging
import pickle
import json
from typing import Dict, List, Tuple, Optional

import numpy as np
import pandas as pd
from tqdm import tqdm

# XGBoost — gradient boosted trees, state-of-the-art for tabular/fingerprint data
import xgboost as xgb

# Scikit-learn — evaluation, cross-validation, preprocessing
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import (
    roc_auc_score,
    average_precision_score,   # PR-AUC
    matthews_corrcoef,
    confusion_matrix,
    classification_report,
)
from sklearn.preprocessing import StandardScaler
import joblib

logger = logging.getLogger("ToxIQ.ModelTrainer")


# =============================================================================
# CONSTANTS — Model Configuration
# =============================================================================

# XGBoost hyperparameters — tuned for cheminformatics fingerprint data
# These were selected based on published benchmarks on the Tox21 challenge.
XGBOOST_PARAMS = {
    "n_estimators":      300,      # Number of boosting rounds
    "max_depth":         6,        # Tree depth: 6 is a sweet spot for FP data
    "learning_rate":     0.05,     # Small LR → more rounds, better generalization
    "subsample":         0.8,      # Row sampling per tree: prevents overfitting
    "colsample_bytree":  0.7,      # Feature sampling per tree: critical for FPs
                                   #   (2048 bits → sample ~1434 per tree)
    "min_child_weight":  5,        # Minimum sum of instance weight per leaf
                                   #   Prevents fitting to tiny minority clusters
    "gamma":             0.1,      # Minimum loss reduction for split: regularization
    "reg_alpha":         0.1,      # L1 regularization: promotes sparse solutions
                                   #   (useful: most FP bits are uninformative)
    "reg_lambda":        1.0,      # L2 regularization: standard weight decay
    "scale_pos_weight":  1,        # Overridden per-task with actual class ratio
    "random_state":      42,
    "n_jobs":            -1,       # Use all CPU cores
    "eval_metric":       "auc",
    "tree_method":       "hist",   # Histogram-based: fast for high-dim data
}

N_CV_FOLDS = 5  # 5-fold stratified cross-validation


# =============================================================================
# SECTION 1: Per-Task Data Preparation
# =============================================================================

def prepare_task_data(
    X: np.ndarray,
    Y: np.ndarray,
    task_idx: int,
    scaler: Optional[StandardScaler] = None,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Prepare data for a single toxicity assay task.

    KEY DECISIONS:
        1. Remove NaN labels: Unlabeled compounds are excluded from training.
           We do NOT impute labels — this would introduce false negatives.
        2. Scale descriptors: The last 13 columns (physicochemical descriptors)
           have different scales (MW in 500s, LogP in -5 to +10, etc.).
           We standardize these while LEAVING fingerprint bits (0/1) unchanged.
        3. Return both raw mask and processed arrays for flexibility.

    Args:
        X: Full feature matrix (N, 2061)
        Y: Full label matrix (N, 12)
        task_idx: Index of the assay to prepare
        scaler: If provided, use existing scaler (for test set); else fit new one

    Returns:
        X_task: Features for labeled samples
        y_task: Binary labels for labeled samples
        labeled_mask: Boolean mask for which samples have labels
        scaler: Fitted StandardScaler for descriptor columns
    """
    y_col = Y[:, task_idx]
    labeled_mask = ~np.isnan(y_col)

    X_task = X[labeled_mask].copy()
    y_task = y_col[labeled_mask].astype(int)

    # Standardize only the physicochemical descriptor columns (last 13)
    # Morgan fingerprint bits are already binary {0, 1} — don't scale them.
    fp_cols = slice(0, 2048)       # Morgan fingerprint bits
    desc_cols = slice(2048, None)  # Physicochemical descriptors

    if scaler is None:
        scaler = StandardScaler()
        X_task[:, desc_cols] = scaler.fit_transform(X_task[:, desc_cols])
    else:
        X_task[:, desc_cols] = scaler.transform(X_task[:, desc_cols])

    return X_task, y_task, labeled_mask, scaler


# =============================================================================
# SECTION 2: Model Training
# =============================================================================

def train_single_task_model(
    X_task: np.ndarray,
    y_task: np.ndarray,
    task_name: str,
    use_cv: bool = True,
) -> Tuple[xgb.XGBClassifier, dict]:
    """
    Train an XGBoost classifier for one toxicity assay.

    TRAINING STRATEGY:
        1. Compute class weight ratio → pass to scale_pos_weight
        2. If use_cv=True, run 5-fold cross-validation first to report metrics
        3. Train final model on ALL available labeled data (no test holdout here)
           → full data utilization, evaluation via CV

    CLASS WEIGHT COMPUTATION:
        scale_pos_weight = count(negatives) / count(positives)
        This directly tells XGBoost to weigh each positive sample that many
        times more heavily than each negative sample.

        Example: 1000 non-toxic, 50 toxic → scale_pos_weight = 20
        The model will treat each toxic compound as 20 non-toxic compounds
        during optimization — correctly prioritizing minority class.

    Args:
        X_task: Feature matrix for labeled samples of this task
        y_task: Binary labels
        task_name: Assay name for logging
        use_cv: Whether to run cross-validation for metrics

    Returns:
        Trained XGBClassifier and dict of evaluation metrics
    """
    # Compute class imbalance ratio for this specific assay
    n_pos = y_task.sum()
    n_neg = len(y_task) - n_pos
    pos_weight = n_neg / max(n_pos, 1)  # Avoid division by zero

    logger.info(
        f"  {task_name}: {len(y_task)} labeled | "
        f"{n_pos} active ({100*n_pos/len(y_task):.1f}%) | "
        f"scale_pos_weight={pos_weight:.1f}"
    )

    # Configure model with task-specific class weight
    params = XGBOOST_PARAMS.copy()
    params["scale_pos_weight"] = pos_weight

    model = xgb.XGBClassifier(**params)

    metrics = {}

    if use_cv and len(y_task) >= 50:  # Need enough samples for CV
        # Stratified K-Fold preserves class proportions in each fold
        cv = StratifiedKFold(n_splits=N_CV_FOLDS, shuffle=True, random_state=42)

        cv_aucs = []
        cv_praucs = []

        for fold, (train_idx, val_idx) in enumerate(cv.split(X_task, y_task)):
            X_tr, X_val = X_task[train_idx], X_task[val_idx]
            y_tr, y_val = y_task[train_idx], y_task[val_idx]

            # Skip folds where validation set has only one class
            if len(np.unique(y_val)) < 2:
                continue

            fold_model = xgb.XGBClassifier(**params)
            fold_model.fit(
                X_tr, y_tr,
                eval_set=[(X_val, y_val)],
                verbose=False,
            )

            y_prob = fold_model.predict_proba(X_val)[:, 1]
            cv_aucs.append(roc_auc_score(y_val, y_prob))
            cv_praucs.append(average_precision_score(y_val, y_prob))

        if cv_aucs:
            metrics["cv_roc_auc"] = {
                "mean": float(np.mean(cv_aucs)),
                "std": float(np.std(cv_aucs)),
            }
            metrics["cv_pr_auc"] = {
                "mean": float(np.mean(cv_praucs)),
                "std": float(np.std(cv_praucs)),
            }
            logger.info(
                f"    CV ROC-AUC: {metrics['cv_roc_auc']['mean']:.3f} "
                f"± {metrics['cv_roc_auc']['std']:.3f} | "
                f"PR-AUC: {metrics['cv_pr_auc']['mean']:.3f}"
            )

    # Train final model on ALL labeled data for this task
    model.fit(X_task, y_task, verbose=False)

    metrics["n_samples"] = int(len(y_task))
    metrics["n_active"] = int(n_pos)
    metrics["class_ratio"] = float(pos_weight)

    return model, metrics


def train_all_tasks(
    X: np.ndarray,
    Y: np.ndarray,
    assay_names: List[str],
    model_dir: str = "models/",
    use_cv: bool = True,
) -> Tuple[Dict, Dict, Dict]:
    """
    Train the complete multi-task toxicity prediction system.

    MULTI-TASK TRAINING LOOP:
        For each of the 12 assays:
            1. Extract labeled samples (remove NaN)
            2. Compute class weights
            3. Run cross-validation → metrics
            4. Train final model on all labeled data
            5. Save model to disk

        Result: 12 task-specific XGBoost models sharing the same
        feature representation but optimized independently.

    WHY NOT JOINT TRAINING?
        XGBoost doesn't natively support multi-output classification with
        different sample sets per output (our missing label problem).
        The independent-model approach with shared hyperparameters is the
        practical industry standard for this setting.

    Args:
        X: Feature matrix (N, 2061)
        Y: Label matrix (N, 12) — may contain NaN
        assay_names: List of assay names (len=12)
        model_dir: Directory to save trained models
        use_cv: Run 5-fold cross-validation

    Returns:
        models: {assay_name: XGBClassifier}
        scalers: {assay_name: StandardScaler}
        all_metrics: {assay_name: metrics_dict}
    """
    os.makedirs(model_dir, exist_ok=True)
    logger.info("=" * 60)
    logger.info("Training Multi-Task Toxicity Prediction Models")
    logger.info("=" * 60)

    models = {}
    scalers = {}
    all_metrics = {}

    for task_idx, task_name in enumerate(assay_names):
        logger.info(f"\n[Task {task_idx+1}/{len(assay_names)}] {task_name}")

        # Prepare task-specific data with label filtering
        X_task, y_task, _, scaler = prepare_task_data(X, Y, task_idx)

        if len(y_task) < 20:
            logger.warning(f"  Skipping {task_name}: insufficient labeled samples ({len(y_task)})")
            continue

        if len(np.unique(y_task)) < 2:
            logger.warning(f"  Skipping {task_name}: only one class present")
            continue

        # Train model
        model, metrics = train_single_task_model(X_task, y_task, task_name, use_cv)

        models[task_name] = model
        scalers[task_name] = scaler
        all_metrics[task_name] = metrics

        # Persist model and scaler
        joblib.dump(model, os.path.join(model_dir, f"{task_name}_model.pkl"))
        joblib.dump(scaler, os.path.join(model_dir, f"{task_name}_scaler.pkl"))

    # Save metrics summary
    metrics_path = os.path.join(model_dir, "training_metrics.json")
    with open(metrics_path, "w") as f:
        json.dump(all_metrics, f, indent=2)

    logger.info(f"\nAll models saved to: {model_dir}")
    logger.info(f"Metrics saved to: {metrics_path}")
    _log_metrics_summary(all_metrics)

    return models, scalers, all_metrics


def _log_metrics_summary(all_metrics: dict):
    """Print a clean summary table of cross-validation performance."""
    logger.info("\n" + "=" * 60)
    logger.info("CROSS-VALIDATION PERFORMANCE SUMMARY")
    logger.info("=" * 60)
    logger.info(f"{'Assay':<20} {'ROC-AUC':>10} {'± Std':>8} {'PR-AUC':>10}")
    logger.info("-" * 50)

    aucs = []
    for task, m in all_metrics.items():
        if "cv_roc_auc" in m:
            auc = m["cv_roc_auc"]["mean"]
            std = m["cv_roc_auc"]["std"]
            prauc = m["cv_pr_auc"]["mean"]
            aucs.append(auc)
            logger.info(f"{task:<20} {auc:>10.3f} {std:>8.3f} {prauc:>10.3f}")

    if aucs:
        logger.info("-" * 50)
        logger.info(f"{'MEAN':20} {np.mean(aucs):>10.3f}")
    logger.info("=" * 60)


# =============================================================================
# SECTION 3: Inference Pipeline
# =============================================================================

def load_models(model_dir: str, assay_names: List[str]) -> Tuple[Dict, Dict]:
    """
    Load all trained models and scalers from disk.

    Used by the Streamlit dashboard for inference on new molecules.
    """
    models = {}
    scalers = {}

    for task_name in assay_names:
        model_path = os.path.join(model_dir, f"{task_name}_model.pkl")
        scaler_path = os.path.join(model_dir, f"{task_name}_scaler.pkl")

        if os.path.exists(model_path) and os.path.exists(scaler_path):
            models[task_name] = joblib.load(model_path)
            scalers[task_name] = joblib.load(scaler_path)
        else:
            logger.warning(f"Model not found for {task_name}")

    logger.info(f"Loaded {len(models)} task models from {model_dir}")
    return models, scalers


def predict_toxicity(
    smiles: str,
    models: Dict,
    scalers: Dict,
    feature_names: List[str],
) -> Optional[pd.DataFrame]:
    """
    Run full toxicity prediction for a single input SMILES.

    INFERENCE PIPELINE:
        SMILES → Mol → [Morgan FP | Descriptors] → Scale descriptors
        → Per-task XGBoost prediction → Probability scores
        → Risk classification

    RISK THRESHOLDS:
        We use calibrated probability thresholds for clinical communication:
        - < 0.3:  Low risk
        - 0.3–0.6: Moderate risk (flag for expert review)
        - > 0.6:  High risk (structural alert — strong concern)

    Args:
        smiles: Input SMILES string
        models: Dict of {task_name: trained XGBClassifier}
        scalers: Dict of {task_name: fitted StandardScaler}
        feature_names: Feature names for the full vector

    Returns:
        DataFrame with columns: [Assay, Probability, Risk_Level, Pathway_Type]
        Returns None if SMILES is invalid
    """
    from src.data_pipeline import featurize_molecule

    fp, desc = featurize_molecule(smiles)
    if fp is None:
        return None

    desc_values = np.array(list(desc.values()), dtype=np.float32)
    x_raw = np.concatenate([fp, desc_values]).reshape(1, -1)

    results = []

    for task_name, model in models.items():
        if task_name not in scalers:
            continue

        x = x_raw.copy()
        # Scale only descriptor columns
        x[:, 2048:] = scalers[task_name].transform(x[:, 2048:])

        prob = float(model.predict_proba(x)[0, 1])

        # Clinical risk classification
        if prob < 0.30:
            risk_level = "Low"
            risk_color = "🟢"
        elif prob < 0.60:
            risk_level = "Moderate"
            risk_color = "🟡"
        else:
            risk_level = "High"
            risk_color = "🔴"

        # Pathway classification for biological interpretation
        pathway = "Nuclear Receptor" if task_name.startswith("NR-") else "Stress Response"

        results.append({
            "Assay": task_name,
            "Pathway Type": pathway,
            "Toxicity Probability": prob,
            "Risk Level": f"{risk_color} {risk_level}",
            "Risk Score (%)": round(prob * 100, 1),
        })

    if not results:
        return None

    df = pd.DataFrame(results).sort_values("Toxicity Probability", ascending=False)
    return df


# =============================================================================
# SECTION 4: SHAP Feature Importance
# =============================================================================

def compute_shap_values(
    model: xgb.XGBClassifier,
    X_sample: np.ndarray,
    feature_names: List[str],
    task_name: str,
    n_background: int = 100,
) -> Optional[np.ndarray]:
    """
    Compute SHAP values for model explainability.

    SHAP THEORY (for developers):
        SHAP values are rooted in cooperative game theory (Shapley values, 1953).
        Each feature gets a "payout" representing its contribution to the
        model's prediction, averaged over all possible orderings of features.

        For XGBoost, SHAP uses the TreeExplainer — exact computation
        (not approximation) in O(TLD²) where T=trees, L=leaves, D=depth.

        A SHAP value of +0.3 for FP_bit_847 means: this structural feature
        INCREASES the log-odds of toxicity by 0.3. If bit_847 represents
        "N adjacent to aromatic ring," this is a chemical structural alert.

        Sum of all SHAP values + base value = model output (log-odds).

    CLINICAL VALUE:
        SHAP turns the model into a tool chemists can argue with.
        A medicinal chemist can look at the top SHAP bits, decode them
        back to substructures (using RDKit), and understand WHY the model
        flags a compound as toxic. This is the foundation of structural
        alert identification.

    Args:
        model: Trained XGBClassifier
        X_sample: Feature matrix for the compound(s) to explain
        feature_names: List of feature names (len=2061)
        task_name: Assay name for labeling
        n_background: Background dataset size for SHAP

    Returns:
        SHAP values array of shape (n_samples, n_features)
    """
    import shap

    try:
        explainer = shap.TreeExplainer(model)
        shap_values = explainer.shap_values(X_sample)
        return shap_values
    except Exception as e:
        logger.warning(f"SHAP computation failed for {task_name}: {e}")
        return None


if __name__ == "__main__":
    # Demonstration: show model configuration
    print("ToxIQ Model Trainer — Configuration")
    print("=" * 50)
    print(f"Algorithm:          XGBoost (gradient boosted trees)")
    print(f"Tasks:              12 toxicity assays (independent models)")
    print(f"Features:           2048 Morgan FP bits + 13 descriptors = 2061")
    print(f"CV Folds:           {N_CV_FOLDS}-fold stratified")
    print(f"Primary Metric:     ROC-AUC (handles class imbalance)")
    print(f"Imbalance Strategy: scale_pos_weight (per-task class ratio)")
    print(f"\nXGBoost Parameters:")
    for k, v in XGBOOST_PARAMS.items():
        print(f"  {k:25s}: {v}")
